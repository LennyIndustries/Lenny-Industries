--Arc Furnace Shiny GFX
require("scripts.arc-furnace_shiny-gfx")
