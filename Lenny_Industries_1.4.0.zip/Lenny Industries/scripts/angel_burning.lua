if settings.startup["AngelBurning_Status"].value and mods["angelspetrochem"] then
	data.raw["fluid"]["gas-methane"].fuel_value = "1.15MJ"

	data.raw["fluid"]["gas-ethane"].fuel_value = "1.175MJ"
	data.raw["fluid"]["gas-ethylene"].fuel_value = "1.175MJ"

	data.raw["fluid"]["gas-propene"].fuel_value = "1.2MJ"

	data.raw["fluid"]["gas-butane"].fuel_value = "1.225MJ"
end
