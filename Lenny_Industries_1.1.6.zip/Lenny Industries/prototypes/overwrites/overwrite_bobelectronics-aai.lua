data:extend({
{
	type = "recipe",
	name = "Stone tablet",
	category = "electronics",
	enabled = true,
	ingredients =
	{
		{"stone-brick", 1},
	},
	energy_requred = 1,
	result = "stone-tablet",
	result_count = 4
}
})
