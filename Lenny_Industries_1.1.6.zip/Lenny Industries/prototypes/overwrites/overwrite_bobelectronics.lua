data:extend({
	{
		type = "recipe",
		name = "wood",
		category = "electronics",
		enabled = true,
		ingredients =
		{
			{"raw-wood", 1},
		},
		result = "wood",
		result_count = 2
	},
	{
		type = "recipe",
		name = "resin",
		category = "electronics",
		enabled = true,
		ingredients =
		{
			{"raw-wood", 5},
		},
		energy_requred = 1,
		result = "resin",
		result_count = 1
	}
})
