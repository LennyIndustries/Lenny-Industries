for name, entity in pairs(data.raw["construction-robot"]) do
	entity.minable = nil
end
