data.raw["boiler"] ["boiler-2"].energy_consumption = "2.7225MW"

data.raw["boiler"] ["boiler-3"].energy_consumption = "3.63MW"
data.raw["boiler"] ["boiler-3"].target_temperature = 235

data.raw["boiler"] ["boiler-4"].energy_consumption = "7.776MW"

data.raw["generator"] ["steam-engine-2"].maximum_temperature = 235
data.raw["generator"] ["steam-engine-3"].maximum_temperature = 375
