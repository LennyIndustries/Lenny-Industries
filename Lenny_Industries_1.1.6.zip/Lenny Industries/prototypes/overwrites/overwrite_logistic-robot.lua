for name, entity in pairs(data.raw["logistic-robot"]) do
	entity.minable = nil
end
